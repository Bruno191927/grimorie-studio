@echo off
cd /d "%~dp0"
echo Instalando certificado en Personas de Confianza del usuario...
certutil -user -addstore -f "TrustedPeople" "%~dp0GrimoireStudio.cer"

:: Si se ejecuta como admin, tambien se agrega a nivel de equipo
net session >nul 2>&1
if %errorLevel% equ 0 (
    certutil -addstore -f "TrustedPeople" "%~dp0GrimoireStudio.cer"
    certutil -addstore -f "Root" "%~dp0GrimoireStudio.cer"
)

echo.
echo ========================================================
echo   Certificado instalado con exito!
echo   Ya puedes hacer doble clic en 'grimoire_studio.msix'
echo ========================================================
echo.
pause
